<?php
  //Recogemos la variable enviada desde analiza.html
if(!$_POST) {
  header("Location: ./index.html");
  exit;
 } else {
  $nombrefichero = (isset($_POST['nombrefichero'])) ? $_POST['nombrefichero'] : NULL;
 }
echo "<br>";
echo "<blockquote>El nombre del fichero a analizar es: <font color=\"red\"><b>$nombrefichero</b></font>";
echo "<br><br><br>";

if (!function_exists("ssh2_connect")) die("function ssh2_connect doesn't exist");
// log in at server1.example.com on port 22
if(!($con = ssh2_connect("surco", 22))){
  echo "fail: unable to establish connection\n";
 } else {
  // try to authenticate with username root, password secretpassword
  if(!ssh2_auth_password($con, "godo", "navas73")) {
    echo "fail: unable to authenticate\n";
  } else {
    // allright, we're in!
    echo "okay: logged in...<br>";
    
    // execute a command
    if (!($stream = ssh2_exec($con, "/usr/bin/avast -a -r /tmp/avast-web-scan.txt \"/mnt/vm/aa-almacen/AA-DESCARGAS_RECIENTES/$nombrefichero\"" ))) {
      echo "fail: unable to execute command\n";
    } else {
      // collect returning data from command
      stream_set_blocking($stream, true);
      /*
      $data = "";
      while ($buf = fread($stream,4096)) {
	$data .= $buf;
	}*/
      echo "Leyendo stream...<br><br>";
      //echo "Output: " . stream_get_contents($stream);
      // Con el siguiente while mostramos las líneas una a una
      stream_set_blocking($stream, true);
      while($line = fgets($stream)) {
	flush();
	echo $line."<br />";
      } 
      // Cerramos el stream
      fclose($stream);
    }
  }
 }

?>
